
## Sections
- Part1: Responsive Home Page Design.
- Part2: Shop Page & Single Product Page.
- Part3: Blog Page.
- Part4: About Page.
- Part5: Contact Us.
- Part6: Ecommerce Shopping Cart.

